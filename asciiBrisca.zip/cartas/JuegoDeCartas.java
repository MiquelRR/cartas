package cartas;

abstract public class JuegoDeCartas {
    abstract int ganaMano(Carta carta1, Carta carta2);
} 
