javac ./cartas/*.java
javac *.java
java asciiBrisca.java

