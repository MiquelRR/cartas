# AscciBrisca
Se basa en una prácrtica del ciclo superior DAM
sobre POO </br>
Is based in an OOP exercice of Multiplatform Apps Development  </br>
Compilar primero las clases y después AsciiBrisca.java

